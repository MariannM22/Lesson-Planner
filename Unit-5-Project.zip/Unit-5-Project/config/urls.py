"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from django.contrib import admin

import app.views
# from . import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path("", app.views.admin_home, name="bananna"),
    path('register/', app.views.register, name="register"),
    path('login/', app.views.user_login, name="login"),
    path('logout/', app.views.logoutUser, name="logout"),
    path("home/", app.views.home, name="home"),
    path('create/', app.views.create, name = "create"),
    path('update/<str:pk>/', app.views.update, name = "update"),
    path('delete/<str:pk>/', app.views.delete, name = "delete"),
    

    # path('', views.home),
    # path('products/', views.products),
    # path('customer/', views.customer),
]
