# from django.contrib.auth import logout,login,authenticate

from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import TemplateView
from .forms import Create_User_Form
from django.contrib import messages
from django.contrib.auth.models import Group
from typing import List
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from .models import Product
from django.contrib.auth.decorators import login_required
from .decorators import unauthenticated_user, admin_only
from .forms import Amine



# @unauthenticated_user
def register(request):

	forms = Create_User_Form()
	if request.method == "POST":
		forms = Create_User_Form(request.POST)
		if forms.is_valid():
			user = forms.save()
			username = forms.cleaned_data.get("username")
			messages.success(request, "Created " + username)
			group = Group.objects.get(name = "customer")
			user.groups.add(group)
			return redirect("login")
	context = {"form":forms}
	return render(request, 'pages/register.html', context)

@unauthenticated_user
def user_login(request):
		if request.method == "POST":
			username = request.POST.get("username")
			password1 = request.POST.get("password")
			user = authenticate(request, username=username, password=password1)
			if user is not None:
				login(request, user)
				return redirect('bananna')
			else:
				messages.info(request, "Invalid Login. Please try again.")
		context={}
		return render(request, 'pages/login.html', context)



def logoutUser(request):
	logout(request)
	return redirect('login')

@login_required(login_url='login')
def home(request):
	prod = Product.objects.all()
	context = {"Prod": prod}
	return render(request, 'pages/home.html', context)

def create(request):
	form = Amine()
	if request.method == "POST":
		form = Amine(request.POST)
		if form.is_valid():
			form.save()
			return redirect('home')
	context = {"form": form}
	return render(request, "pages/create.html", context)


def update(request, pk):
	ok = Product.objects.get(id=pk)
	form = Amine(instance=ok)
	if request.method == "POST":
		form = Amine(request.POST, instance=ok)
		if form.is_valid():
			form.save()
			return redirect("home")
	context = {"form":form}
	return render(request, "pages/create.html", context)

def delete(request, pk):
	ok2 = Product.objects.get(id=pk)
	if request.method == "POST":
		ok2.delete()
		return redirect("home")
	context = {"ok2": ok2}
	return render (request, "pages/delete.html", context)

@admin_only
def admin_home(request):
	prod = Product.objects.all()
	context = {"Prod": prod}
	return render(request, 'pages/admin.html', context)



# def to_watch(request):

# 	return render(request, 'pages/to_watch.html')

# def watched_list(request):
# 	return render(request, 'pages/undiscovered.html')


# 	AA = []
# 	AA.append(input("")), options = [
#   "To Watch"
#   "Watched List"
# ]
# 	context = {options}